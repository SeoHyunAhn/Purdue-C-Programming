// Problem ( 1/4 ) 
/******************************************************************************
 * TODO: Add toPush to the list in the specified index. Reallocate the array
 *       if necessary. If the index is not within the current bounds of the
 *       array, simply return (i.e., if index < 0 or index > m_size).
 * 
 * Parameters: toPush -- the thing you are storing
 *             index  -- the index in the list in which toPush should go.
 *
 * Return: void 
 *
 * Return Type: void
 *****************************************************************************/
template<class T>
void ArrayList<T>::add(const T& toPush, int index)
{
    // Write Your Code Here
}

// Problem ( 2/4 ) 
/******************************************************************************
 * TODO: Remove the first instance of the given object within the array. If the
 *       parameter ok is set to a location other than null, ok is set to false
 *       if the removal fails and is set to true otherwise.
 *
 * Parameters: toRemove -- the thing to remove.
 *             ok       -- boolean value representing successful removal.
 *
 * Return: A copy of the removed element.
 *
 * Return Type: T
 *****************************************************************************/
template<class T>
T ArrayList<T>::remove(const T & toRemove, bool * ok)
{
    // Write Your Code Here
}

// Problem (3/4)
/********************************************************************************
 * TODO: Find the nth index of an object within the array. The occurrence variable
 *       starts at 1 (1st occurrence is the first time we see it in the array).
 *       You may assume that occurrence is >= 1. If the object is not found,
 *       return -1.
 *
 * 
 * Parameters: object -- the object you are trying to locate.
 *         occurrence --
 *
 * Return: Return 0 if the head is equal to NULL.
 *     Return 1 otherwise.  
 *
 * Return Type: integer
 *****************************************************************************/
template<class T>
int ArrayList<T>::indexOf(const T& object, int occurrence)
{
    // Write Your Code Here
    return 0;
}


// Problem ( 4/4 ) 
/******************************************************************************
 * TODO: Clear the list! NOTE: YOU MUST DEALLOCATE THE ARRAY!
 *
 * Parameters: 
 *
 * Return: void 
 *
 * Return Type: void
 *****************************************************************************/
template<class T>
void ArrayList<T>::clear()
{
    // Write Your Code Here
}
